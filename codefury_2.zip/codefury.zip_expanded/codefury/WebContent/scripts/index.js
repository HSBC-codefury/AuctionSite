/**
 * 
 */ 
 var registerBtn = document.querySelector("#register")
 var loginBtn = document.querySelector("#login")
  
 registerBtn.addEventListener("click",()=>{
 
	window.location.href = "Register.jsp"
 
 })
 
loginBtn.addEventListener("click",()=>{
 console.log("login")
 window.location.href="Login.jsp"
 
 })