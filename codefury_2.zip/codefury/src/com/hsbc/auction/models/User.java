package com.hsbc.auction.models;

import java.time.LocalDate;

public class User {

	private String name;
	private LocalDate dob;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getContactNo() {
		return contactNo;
	}

	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public double getWalletAmount() {
		return walletAmount;
	}

	public void setWalletAmount(double walletAmount) {
		this.walletAmount = walletAmount;
	}

	private String email;
	private long contactNo;
	private String userName;
	private String password;
	private String Address;
	private String userType;
	private double walletAmount;

	@Override
	public String toString() {
		return "User [name=" + name + ", dob=" + dob + ", email=" + email + ", contactNo=" + contactNo + ", userName="
				+ userName + ", password=" + password + ", Address=" + Address + ", userType=" + userType
				+ ", walletAmount=" + walletAmount + "]";
	}
	
	
}
