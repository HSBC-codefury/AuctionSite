package com.hsbc.auction.models;

public enum UserStatus {
	OPEN,WON,LOST
}
