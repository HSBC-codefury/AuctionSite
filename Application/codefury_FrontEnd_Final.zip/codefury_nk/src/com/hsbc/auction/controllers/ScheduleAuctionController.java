
package com.hsbc.auction.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.InputMismatchException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hsbc.auction.dao.ProductDao;
import com.hsbc.auction.dao.ProductImpl;
import com.hsbc.auction.models.Product;

/**
 * Servlet implementation class ScheduleAuctionController
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/ScheduleAuctionController" })
public class ScheduleAuctionController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ScheduleAuctionController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
//	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			System.out.println("inside schedule auction controller");

			Product product = new Product();
			String productNameAndId = request.getParameter("productAndId");
			System.out.println(productNameAndId);
			String[] arrOfStr = productNameAndId.split(" "); 
			String productName = arrOfStr[1];
			System.out.println("product name" + productName);
			int productId = Integer.parseInt(arrOfStr[0]);
			System.out.println("product id" + productId);
			int minBidValue = Integer.parseInt(request.getParameter("minbidvalue"));
			LocalDate bidStartDate = LocalDate.parse(request.getParameter(("bidstartdate")).toString(), formatter);
			LocalDate bidEndDate = LocalDate.parse(request.getParameter(("bidenddate")).toString(), formatter);

			
			PrintWriter out = response.getWriter();
			HttpSession session = null;
			session = request.getSession();
			response.setContentType("text/html");
			ProductDao productDao = new ProductImpl();		

			product.setProductName(productName);
			product.setMinBidValue(minBidValue);
			product.setBidStartDate(bidStartDate);
			product.setBidEndDate(bidEndDate);
			product.setProductUniqueId(productId);
			/*
			 * // product.setProductUniqueId(productDao.getProductId());
			 */			
			product.setAuctionUserId(productDao.getUserId(session.getAttribute("username").toString()));
			System.out.println("product print" + product);
			

			 if(productDao.ScheduleAuction(product))
			{

			session = request.getSession(true);
			session.setAttribute("ScheduleSession", product);
			
			System.out.println("Check the list of product auction");
			System.out.println(product);
			session.setAttribute("productList",productDao.auctionedProd((ArrayList<Product>) session.getAttribute("productList")));
			request.getRequestDispatcher("Seller.jsp").forward(request, response);
			}
			// }
			// else
			// request.getRequestDispatcher("scheduleauction.html").forward(request,
			// response);

		} catch (NullPointerException | InputMismatchException exception) {
			System.out.println(exception.getMessage());
			exception.printStackTrace();
			// response.sendError(response.SC_EXPECTATION_FAILED,"Data Error");
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
			exception.printStackTrace();
			// response.sendError(response.SC_EXPECTATION_FAILED,"Data Error");
		}
	}

}
