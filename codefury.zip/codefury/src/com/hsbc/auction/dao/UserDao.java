package com.hsbc.auction.dao;

import java.sql.SQLException;
import java.util.List;

import com.hsbc.auction.models.User;

public interface UserDao {
	
	boolean addCustomer(User user) throws SQLException;
	List<User> validateLogin(User user);
	
	
}
