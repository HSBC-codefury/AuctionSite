package com.hsbc.auction.models;

import java.time.LocalDate;

public class Product extends Category{


	@Override
	public String toString() {
		return "Product [productUniqueId=" + productUniqueId + ", productName=" + productName + ", productCategory="
				+ productCategory + ", productDescription=" + productDescription + ", productActualPrice="
				+ productActualPrice + ", productQuantity=" + productQuantity + ", productUserId=" + productUserId
				+ "]";
	}
	private int productUniqueId;
	private String productName;
	private String productCategory;
	private String productDescription;
	private double productActualPrice;
	private int productQuantity;
	private int productUserId;
	
	private int auctionUniqueId;
	private double minBidValue;
	private LocalDate bidStartDate;
	private LocalDate bidEndDate;
	private int auctionUserId;
	private double soldPrice;
	private Status status;
	
	
	public int getProductUniqueId() {
		return productUniqueId;
	}
	public void setProductUniqueId(int productUniqueId) {
		this.productUniqueId = productUniqueId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public double getProductActualPrice() {
		return productActualPrice;
	}
	public void setProductActualPrice(double productActualPrice) {
		this.productActualPrice = productActualPrice;
	}
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public int getProductUserId() {
		return productUserId;
	}
	public void setProductUserId(int productUserId) {
		this.productUserId = productUserId;
	}
	
	public int getAuctionUniqueId() {
		return auctionUniqueId;
	}
	public void setAuctionUniqueId(int auctionUniqueId) {
		this.auctionUniqueId = auctionUniqueId;
	}
	
	public double getMinBidValue() {
		return minBidValue;
	}
	public void setMinBidValue(double minBidValue) {
		this.minBidValue = minBidValue;
	}
	public LocalDate getBidStartDate() {
		return bidStartDate;
	}
	public void setBidStartDate(LocalDate bidStartDate) {
		this.bidStartDate = bidStartDate;
	}
	public LocalDate getBidEndDate() {
		return bidEndDate;
	}
	public void setBidEndDate(LocalDate bidEndDate) {
		this.bidEndDate = bidEndDate;
	}

	public int getAuctionUserId() {
		return auctionUserId;
	}
	public void setAuctionUserId(int auctionUserId) {
		this.auctionUserId = auctionUserId;
	}
	public double getSoldPrice() {
		return soldPrice;
	}
	public void setSoldPrice(double soldPrice) {
		this.soldPrice = soldPrice;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	

	/*
	 * @Override public String toString() { return "Product [productUniqueId=" +
	 * productUniqueId + ", productName=" + productName + ", productCategory=" +
	 * productCategory + ", productDescription=" + productDescription +
	 * ", productActualPrice=" + productActualPrice + ", productQuantity=" +
	 * productQuantity + ", productUserId=" + productUserId + ", auctionUniqueId=" +
	 * auctionUniqueId + ", minBidValue=" + minBidValue + ", bidStartDate=" +
	 * bidStartDate + ", bidEndDate=" + bidEndDate + ", auctionUserId=" +
	 * auctionUserId + ", soldPrice=" + soldPrice + ", status=" + status + "]"; }
	 */
	
	
	
}
