package com.hsbc.auction.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.InputMismatchException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hsbc.auction.dao.ProductDao;
import com.hsbc.auction.dao.ProductImpl;
import com.hsbc.auction.models.Category;
import com.hsbc.auction.models.Product;

/**
 * Servlet implementation class AddProductController
 */
@WebServlet("/AddProductController")
public class AddProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	private static int id = 1;
	String st;

	public AddProductController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		Enumeration enumeration = request.getParameterNames();

		String parameterName;
		String value = null;
		Category category = new Category();
		Product product = new Product();

		List productData = new ArrayList();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		ProductDao productDao = new ProductImpl();

		try {
			while (enumeration.hasMoreElements()) {
				parameterName = enumeration.nextElement().toString();
				System.out.println("parameter name=" + parameterName);
				value = request.getParameter(parameterName);
				System.out.println("values=" + value);
				productData.add(value);
			}
			try {

				System.out.println(productDao.getUserId(st));
				product.setProductUserId(productDao.getUserId(st));
				product.setProductUniqueId(id++);
				product.setProductName(productData.get(0).toString());
				product.setProductCategory(productData.get(3).toString());
				product.setProductDescription(productData.get(2).toString());
				product.setProductActualPrice(Double.parseDouble(productData.get(1).toString()));
				product.setProductQuantity(Integer.parseInt(productData.get(4).toString()));

				HttpSession session = request.getSession();
				st = session.getAttribute("username").toString();
				System.out.println("70");
				System.out.println("username= " + st);

			} catch (Exception exception) {
				System.out.print(exception.getMessage());

			}
			// product.setProductUserId((int) productData.get(6));
			System.out.println(product);
			// out.println("Product Added Successfully...");

			System.out.println("calling dao... ");
			if (productDao.addProduct(product) == true) {
				// System.out.println(product.getProductName());

				System.out.println("Product Added Successfully...");

				request.setAttribute("addProduct", "true");
				request.getRequestDispatcher("Seller.jsp").forward(request, response);
//			out.println("INSERTED");
			} else {
				out.println("NAAAHHHHH");
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
}
