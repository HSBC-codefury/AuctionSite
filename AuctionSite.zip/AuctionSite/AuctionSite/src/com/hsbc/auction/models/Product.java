package com.hsbc.auction.models;

import java.time.LocalDate;

public class Product {
	private int uniqueProductId;
	private String productName;
	private Category category;
	private String description;
	private double actualPrice;
	private int quantity;
	private int sellerId;
	
	private int minBidValue;
	private LocalDate bidStartDate;
	private LocalDate bidEndDate;
	private int buyerId;
	private double soldPrice;
	private Status status;
	public int getUniqueProductId() {
		return uniqueProductId;
	}
	public void setUniqueProductId(int uniqueProductId) {
		this.uniqueProductId = uniqueProductId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getActualPrice() {
		return actualPrice;
	}
	public void setActualPrice(double actualPrice) {
		this.actualPrice = actualPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public int getMinBidValue() {
		return minBidValue;
	}
	public void setMinBidValue(int minBidValue) {
		this.minBidValue = minBidValue;
	}
	public LocalDate getBidStartDate() {
		return bidStartDate;
	}
	public void setBidStartDate(LocalDate bidStartDate) {
		this.bidStartDate = bidStartDate;
	}
	public LocalDate getBidEndDate() {
		return bidEndDate;
	}
	public void setBidEndDate(LocalDate bidEndDate) {
		this.bidEndDate = bidEndDate;
	}
	public int getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}
	public double getSoldPrice() {
		return soldPrice;
	}
	public void setSoldPrice(double soldPrice) {
		this.soldPrice = soldPrice;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	
}
