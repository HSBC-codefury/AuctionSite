package com.hsbc.auction.models;

public enum Status {
	NEW,COMPLETED_SOLD,COMPLETED_NOTSOLD,OPEN;
}
