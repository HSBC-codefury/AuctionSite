package com.hsbc.auction.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hsbc.auction.dao.UserDao;
import com.hsbc.auction.dao.UserImpl;
import com.hsbc.auction.models.User;

/**
 * Servlet implementation class RegisterController
 */
@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Enumeration<String> enumeration = request.getParameterNames();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String parameterName = null;
		String value = null;
		User user = new User();
		List<String> userData = new ArrayList<String>();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		try {

			while (enumeration.hasMoreElements()) {
				parameterName = enumeration.nextElement().toString();
				System.out.println(parameterName);
				value = request.getParameter(parameterName);
				userData.add(value);
			}

			user.setName(userData.get(0).toString());

			user.setDob(LocalDate.parse(userData.get(1).toString(), formatter));

			user.setEmail(userData.get(2).toString());
			user.setContactNo(Long.parseLong(userData.get(3).toString()));
			user.setUserName(userData.get(4).toString());
			user.setWalletAmount(Double.parseDouble(userData.get(5).toString()));
			user.setPassword(userData.get(6).toString());
			user.setAddress(userData.get(7).toString());
			user.setUserType(userData.get(8).toString());
			
			// create conn with dao
			System.out.println("check1"+userData);

			UserDao userDao = new UserImpl();
			if (userDao.addCustomer(user)) {
				System.out.println(user.getUserName());
				//out.println(user.getUserName());
				//out.println(user.getUserType());
				
				request.getRequestDispatcher("Login.jsp").forward(request, response);
//				out.println("INSERTED");
//				request.getRequestDispatcher("Login.html").forward(request, response);
			} else {
				//out.println("NAAAHHHHH");
			}
				
		} catch (Exception e) {
			e.getMessage();
		}

//		String email = request.getParameter("email");
//		String pwd = request.getParameter("psw");	
//		String bors = request.getParameter("bors");
//		Customer customer = new Customer();
//		CustomerDao custDao = new CustomerImpl();
//		PrintWriter out = response.getWriter();
//		customer.setEmail(email);	
//		customer.setPassword(pwd);
//		customer.setBors(bors);
//		boolean result = custDao.addCustomer(customer);
//		if(result) {
//			System.out.println("Record added successfully");
//			out.println(customer.getEmail());
//			out.println(customer.getBors());
//			
//		}

	
	}

}
