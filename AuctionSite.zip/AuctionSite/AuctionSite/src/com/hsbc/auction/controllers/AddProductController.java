package com.hsbc.auction.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hsbc.auction.dao.ProductDao;
import com.hsbc.auction.dao.ProductImpl;

import com.hsbc.auction.models.Category;
import com.hsbc.auction.models.Product;

/**
 * Servlet implementation class AddProductController
 */
@WebServlet("/AddProductController")
public class AddProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddProductController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		Enumeration<String> enumeration = request.getParameterNames();
		String parameterName = null;
		String value = null;
		Product product = new Product();
		Category category = new Category();
		List<String> prodData = new ArrayList<String>();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		try {

			while (enumeration.hasMoreElements()) {
				parameterName = enumeration.nextElement().toString();
				System.out.println(parameterName);
				value = request.getParameter(parameterName);
				prodData.add(value);
			}
			product.setProductName(prodData.get(0));
			category.setCategoryName(prodData.get(1));
			category.setCategoryDescription(prodData.get(2));
			product.setCategory(category);
			product.setActualPrice(Double.parseDouble(prodData.get(3)));
			product.setQuantity(Integer.parseInt(prodData.get(4)));

			// create conn with dao
			System.out.println("check1" + prodData);

			ProductDao prodDao = new ProductImpl();

			if (prodDao.addCategory(category) && prodDao.addProduct(product)) {
				System.out.println("Category and product added");
				// out.println(user.getUserName());
				// out.println(user.getUserType());

				request.getRequestDispatcher("Seller.jsp").forward(request, response);
//				out.println("INSERTED");
//				request.getRequestDispatcher("Login.html").forward(request, response);
			} else {
				// out.println("NAAAHHHHH");
			}

		} catch (Exception e) {
			e.getMessage();
		}

//		String email = request.getParameter("email");
//		String pwd = request.getParameter("psw");	
//		String bors = request.getParameter("bors");
//		Customer customer = new Customer();
//		CustomerDao custDao = new CustomerImpl();
//		PrintWriter out = response.getWriter();
//		customer.setEmail(email);	
//		customer.setPassword(pwd);
//		customer.setBors(bors);
//		boolean result = custDao.addCustomer(customer);
//		if(result) {
//			System.out.println("Record added successfully");
//			out.println(customer.getEmail());
//			out.println(customer.getBors());
//			
//		}

	}

}
