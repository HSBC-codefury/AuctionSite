/**
 * 
 */

var email = document.querySelector("#email")
email.addEventListener("input",()=>{
 console.log(email.value)
})
 