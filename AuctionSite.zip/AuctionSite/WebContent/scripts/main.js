

var Filter_dropdown= document.getElementById("Filter_Categories")
Filter_dropdown.addEventListener("change",(c)=>
{
	console.log(Filter_dropdown.value)
	var cards=document.querySelectorAll(".card");
	
	cards.forEach(card=>card.style.display="flex");
	cards.forEach(card=>
	{	
		let cardAttribute=card.getAttribute("data-product-category");
		
		console.log(card.getAttribute("data-product-category"))
		if((Filter_dropdown.value!="ShowAll") && (cardAttribute!=Filter_dropdown.value))
			card.style.display="none"
		
			
		
	});
});




