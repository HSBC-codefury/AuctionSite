
//declaring variables 

var username = document.querySelector("#username")
var pwd = document.querySelector("#pwd")
var btn = document.querySelector(".btn")
var dispCred= document.querySelector("#displayCred")
btn.addEventListener('click',displayCredentails)

//onlick of the submit
function displayCredentails(event){
    event.preventDefault()
    console.log("clicked")   
    console.log(username.value)
    dispCred.innerHTML = username.value
}
