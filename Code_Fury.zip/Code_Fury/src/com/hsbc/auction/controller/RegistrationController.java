package com.hsbc.auction.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hsbc.auction.dao.UserDao;
import com.hsbc.auction.dao.UserDaoImpl;
import com.hsbc.auction.models.User;

/**
 * Servlet implementation class RegistrationController
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/RegistrationController" })
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		
		Enumeration<String> enumeration=request.getParameterNames();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String parameterName=null;
		String value=null;
		User user=new User();
		List<String> userData=new ArrayList<String>();
		PrintWriter out=response.getWriter();
	    response.setContentType("text/html");
		try
		{
		
		while(enumeration.hasMoreElements())
		{			
			parameterName=enumeration.nextElement().toString();
		    value=request.getParameter(parameterName);
		    userData.add(value);
		}		
		
		user.setName(userData.get(0).toString());
		
		user.setDob(LocalDate.parse(userData.get(1).toString(), 
        		formatter));
		
        user.setEmail(userData.get(2).toString());
        user.setContactNo(Long.parseLong(userData.get(3).toString()));
       user.setUserName(userData.get(4).toString());
       user.setPassword(userData.get(6).toString());
       user.setAddress(userData.get(7).toString());
       user.setUserType(userData.get(8).toString());
       user.setWalletAmount(Double.parseDouble(userData.get(5).toString()));
        //create conn with dao
       
        UserDao userDao=new UserDaoImpl();
        if(userDao.addUser(user))
        {
        	out.println("INSERTED");
        	request.getRequestDispatcher("Login.html").forward(request, response);
        }
        else
        	out.println("NAAAHHHHH");
		}
		catch(Exception e)
		{
			e.getMessage();
		}
}
}