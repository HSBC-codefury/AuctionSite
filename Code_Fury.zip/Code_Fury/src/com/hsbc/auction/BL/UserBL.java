package com.hsbc.auction.BL;

import java.sql.SQLException;
import java.util.List;

import com.hsbc.auction.exceptions.DBConnCreationException;
import com.hsbc.auction.models.User;

public interface UserBL {
	
	List<User> getAllUsers() throws DBConnCreationException;
	boolean addUser(User user) throws DBConnCreationException;

}
