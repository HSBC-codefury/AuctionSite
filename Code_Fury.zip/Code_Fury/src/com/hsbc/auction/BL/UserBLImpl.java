package com.hsbc.auction.BL;

import java.sql.SQLException;
import java.util.List;

import com.hsbc.auction.dao.UserDao;
import com.hsbc.auction.dao.UserDaoImpl;
import com.hsbc.auction.exceptions.DBConnCreationException;
import com.hsbc.auction.models.User;

public class UserBLImpl implements UserBL{

	private UserDao userDao;
	
	
	public UserBLImpl() {
		// TODO Auto-generated constructor stub
		userDao= new UserDaoImpl();
	}

	@Override
	public boolean addUser(User user) throws DBConnCreationException {
		// TODO Auto-generated method stub
		
		boolean status=false;
		try {
			status= userDao.addUser(user);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new DBConnCreationException("DB Connection Error");
		}
		
		return status;
	}

	@Override
	public List<User> getAllUsers() throws DBConnCreationException {
		// TODO Auto-generated method stub
//		
List<User> userList=null;
//		try {
//			//userList=userDao.getAllUsers();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			throw new DBConnCreationException("DB Connection Error");
//		}
//		return userList;
//
//	}
	return userList;
}
}
