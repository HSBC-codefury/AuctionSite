package com.hsbc.auction.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;

import com.hsbc.auction.exceptions.DBConnCreationException;
import com.hsbc.auction.helpers.DBHelper;
import com.hsbc.auction.models.User;

public class UserDaoImpl implements UserDao{
	
	private Connection conn;
	private PreparedStatement pre;
	private ResultSet resultSet;
	private java.sql.Statement stmt;
	private boolean status;
	private ResourceBundle resourceBundle;
	private static int userId=0;
	

	public UserDaoImpl() {

		resourceBundle=ResourceBundle.getBundle("com/hsbc/auction/resources/db");
	}
	

	@Override
	public boolean addUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		try {
			conn=DBHelper.getConnection();
			pre=conn.prepareStatement(resourceBundle.getString("addUsers"));
			userId++;
				pre.setInt(1,userId);
				pre.setString(2, user.getName());
				pre.setDate(3, Date.valueOf(user.getDob()));
				pre.setString(4, user.getEmail());
				pre.setLong(5, user.getContactNo());
				pre.setString(6, user.getUserName());
				pre.setString(7, user.getPassword());
				pre.setString(8, user.getAddress());
				pre.setString(9, user.getUserType());
				pre.setDouble(10, user.getWalletAmount());
				pre.executeUpdate();
			conn.commit();
			status=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getErrorCode());
			conn.rollback();
			throw new SQLException("Connection Error Occurred");
		}
		finally
		{
			conn.close();
		}
		
		return status;
	}

	@Override
	public boolean validateUserName(User user) throws DBConnCreationException {
		// TODO Auto-generated method stub
		boolean stat=false;
		try {
			conn=DBHelper.getConnection();
			pre=conn.prepareStatement(resourceBundle.getString("getUserName"));
			pre.setString(1,user.getUserName());
			System.out.println(user.getUserName());
			resultSet=pre.executeQuery();
			resultSet.next();
			System.out.println(resultSet.getInt(1));
			if(resultSet.getInt(1)>0)
				stat=true;
			else
				stat=false;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return stat;
	}

}
