package com.hsbc.auction.models;

public class BidPlace {
	private int Product_id;
	private double bid_value;
	private int user_Id;
	private UserStatus status;
	
	
	
	@Override
	public String toString() {
		return "BidPlace [Product_id=" + Product_id + ", bid_value=" + bid_value + ", user_Id=" + user_Id + ", status="
				+ status + "]";
	}
	public int getProduct_id() {
		return Product_id;
	}
	public void setProduct_id(int product_id) {
		Product_id = product_id;
	}
	public double getBid_value() {
		return bid_value;
	}
	public void setBid_value(double bid_value) {
		this.bid_value = bid_value;
	}
	public int getUser_Id() {
		return user_Id;
	}
	public void setUser_Id(int user_Id) {
		this.user_Id = user_Id;
	}
	public UserStatus getStatus() {
		return status;
	}
	public void setStatus(UserStatus status) {
		this.status = status;
	}
}
