package com.hsbc.auction.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.InputMismatchException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hsbc.auction.dao.BidDao;
import com.hsbc.auction.dao.BiddaoImpl;
import com.hsbc.auction.dao.ProductDao;
import com.hsbc.auction.dao.ProductImpl;
import com.hsbc.auction.models.BidPlace;
import com.hsbc.auction.models.Product;

/**
 * Servlet implementation class BidPlaceController
 */
@WebServlet("/BidPlaceController")
public class BidPlaceController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BidPlaceController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		ArrayList<Product> auctionList = new ArrayList<Product> ();
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			System.out.println("inside bid controller");

			Product product = new Product();
			BidPlace placeBid = new BidPlace();
			String productNameAndId = request.getParameter("productAndId");
			System.out.println(productNameAndId);
			String[] arrOfStr = productNameAndId.split(" ");
			String productName = arrOfStr[1];
			System.out.println("product name" + productName);
			int productId = Integer.parseInt(arrOfStr[0]);
			System.out.println("product id" + productId);
			double prodMinBidVal = Double.parseDouble(arrOfStr[3].substring(0,arrOfStr[3].length()-1));
			System.out.println("min bid" + prodMinBidVal);

			double minBidValue = Double.parseDouble(request.getParameter("minbidvalue"));
			
			PrintWriter out = response.getWriter();
			HttpSession session = null;
			session = request.getSession();
			response.setContentType("text/html");
			BidDao biddao = new BiddaoImpl();
			ProductDao productDao = new ProductImpl();
			if (minBidValue <= prodMinBidVal) {
				request.getRequestDispatcher("BuyerPage.jsp").forward(request, response);
				}

			else {
				placeBid.setProduct_id(productId);
				placeBid.setBid_value(minBidValue);
				// placeBid.setStatus("UserStatus.OPEN");
				placeBid.setUser_Id(productDao.getUserId(session.getAttribute("username").toString()));
				placeBid.setBid_value(minBidValue);

				if (biddao.storeBidValue(placeBid)) {
					System.out.println("Product Added Successfully...");				
					
					request.getRequestDispatcher("BuyerPage.jsp").forward(request, response);
				} else {
					System.out.println("error 87");
					out.println("<p style='float:right;color:red'>Cannot bid more than one product.</p>");
					request.getRequestDispatcher("BuyerPage.jsp").include(request, response);
				}
			}

			/*
			 * // product.setProductUniqueId(productDao.getProductId());
			 */

		} catch (NullPointerException | InputMismatchException exception) {
			System.out.println(exception.getMessage());
			exception.printStackTrace();
			// response.sendError(response.SC_EXPECTATION_FAILED,"Data Error");
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
			exception.printStackTrace();
			// response.sendError(response.SC_EXPECTATION_FAILED,"Data Error");
		}
	}

}
