package com.hsbc.auction.exceptions;

public class DBQueryExecutionException extends Exception{
	
	public DBQueryExecutionException(String message)
	{
		super(message);
	}

}

