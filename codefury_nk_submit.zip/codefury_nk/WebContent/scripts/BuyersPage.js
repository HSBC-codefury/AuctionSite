/**
 * 
 */
 var userBuyValue = document.querySelector("#bidValue")
var bidInput=document.querySelector("#minbidvalue")
var buttonclick=document.querySelector("#onSubmit")
buttonclick.addEventListener('click',()=>{
console.log("button clicked")
if(bidInput.innerText<userBuyValue.innerText){
alert("error!! have to bid more than given")
window.location.href="BuyerPage.jsp"
}
})
 