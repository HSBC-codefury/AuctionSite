/**
 * 
 */ 
 var registerBtn = document.getElementById("register")
 var loginBtn = document.getElementById("login")
  
 registerBtn.addEventListener("click",()=>{
 
	window.location.href = "Register.jsp"
 
 })
 
loginBtn.addEventListener("click",()=>{
 console.log("login")
 window.location.href="Login.jsp"
 
 })