window.addEventListener('load',(e)=>
{
    var d = new Date();
  var n = d.getFullYear();
  document.getElementById("copyrightyear").innerHTML = n;
})




var Filter_dropdown= document.getElementById("Filter_Categories")
Filter_dropdown.addEventListener("change",(c)=>
{
	console.log(Filter_dropdown.value)
	var cards=document.querySelectorAll(".card");
	
	cards.forEach(card=>card.style.display="flex");
	cards.forEach(card=>
	{	
		let cardAttribute=card.getAttribute("data-product-category");
		
		console.log(card.getAttribute("data-product-category"))
		if((Filter_dropdown.value!="ShowAll") && (cardAttribute!=Filter_dropdown.value))
			card.style.display="none"
	});
});

window.addEventListener("load",(e)=>
{
	function sortList() {
		var status,list,i,b;
	var x= document.querySelectorAll(".card .card-title ")
	var z=document.querySelectorAll(".card") 
	var cardDeck= document.querySelectorAll(".card-deck")
  	list = document.getElementById(cardDeck);
  		status = true;
  /* Make a loop that will continue until
  no switching has been done: */
  	while (status) {
    // start by saying: no switching is done:
    status = false;
    b = list.getElementsByClassName("card");
    // Loop through all list-items:
    for (i = 0; i < (b.length - 1); i++) {
      // start by saying there should be no switching:
      shouldSwitch = false;
      /* check if the next item should
      switch place with the current item: */
      if (b[i].innerHTML.toLowerCase() > b[i + 1].innerHTML.toLowerCase()) {
        /* if next item is alphabetically
        lower than current item, mark as a switch
        and break the loop: */
        shouldSwitch = true;
        break;
      }
    }
    if (shouldSwitch) {
      /* If a switch has been marked, make the switch
      and mark the switch as done: */
      b[i].parentNode.insertBefore(b[i + 1], b[i]);
      switching = true;
    }
  }
}
})


