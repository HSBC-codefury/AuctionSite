package com.hsbc.auction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import com.hsbc.auction.exceptions.DBConnCreationException;
import com.hsbc.auction.helper.DBHelper;
import com.hsbc.auction.models.BidPlace;
import com.hsbc.auction.models.Product;

public class BiddaoImpl implements BidDao {

	private Connection conn = null;
	private PreparedStatement pre;
	private ResultSet resultSet;

	private boolean status;
	private ResourceBundle resourceBundle;

	public BiddaoImpl() {
		resourceBundle = ResourceBundle.getBundle("com/hsbc/auction/resources/db");
	}

	@Override
	public ArrayList<Product> scheduledProd(int userId) {
		// TODO Auto-generated method stub
		ArrayList<Product> productlist = new ArrayList<Product>();
		Product auctionProd = null;
		try {
			conn = DBHelper.getConnection();
			pre = conn.prepareStatement(resourceBundle.getString("displayScheduledProd"));
			resultSet = pre.executeQuery();
			while (resultSet.next()) {
				auctionProd = new Product();
				auctionProd.setProductUniqueId(resultSet.getInt("Product_Id"));
				auctionProd.setBidEndDate(LocalDate.parse(resultSet.getDate("Bid_End_Date").toString()));
				auctionProd.setBidStartDate(LocalDate.parse(resultSet.getDate("Bid_Start_Date").toString()));
				auctionProd.setProductName(resultSet.getString("Product_Name"));
				auctionProd.setMinBidValue(resultSet.getDouble("Min_Bid_Value"));
				auctionProd.setProductCategory(resultSet.getString("Product_Category"));
				
				productlist.add(auctionProd);
				System.out.println("VALUE SET");
				for (Product prodisp : productlist) {
					System.out.println("Display auctioned product" + prodisp);
				}

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("conn established");

		return productlist;
	}

	@Override
	public boolean storeBidValue(BidPlace placeBid) throws DBConnCreationException {
		// TODO Auto-generated method stub
		
		try (Connection conn=DBHelper.getConnection())
		{		
		pre=conn.prepareStatement(resourceBundle.getString("storeBidValue"));
		
	
		pre.setInt(1, placeBid.getProduct_id());
		pre.setDouble(2, placeBid.getBid_value());
		
		
		pre.executeUpdate();
		conn.commit();
		status=true;
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			throw new DBConnCreationException("Connection Error Occurred");
		}
		
		return status;
	}

}
