package com.hsbc.auction.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DBHelper {
	//open the connection
	//get the db details
	//load the driver
	// pass the details to the connection
	
	private static Connection conn = null;
	private static ResourceBundle resBundle;
	
	
	public static Connection getConnection() throws SQLException {
		resBundle = ResourceBundle.getBundle("com/hsbc/auction/resources/db");
		String url = resBundle.getString("url");
		String username = resBundle.getString("username");
		String password = resBundle.getString("password");
		String driver = resBundle.getString("driver");
		
		
		try {
			//loading the driver
			Class.forName(driver);
			conn = DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
	}
	
	

}
