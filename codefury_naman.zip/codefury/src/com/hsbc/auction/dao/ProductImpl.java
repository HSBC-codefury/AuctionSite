package com.hsbc.auction.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.servlet.http.HttpSession;

import com.hsbc.auction.exceptions.DBConnCreationException;
import com.hsbc.auction.models.Category;
import com.hsbc.auction.models.Product;
import com.hsbc.auction.models.User;
import com.hsbc.auction.helper.DBHelper;


public class ProductImpl implements ProductDao{
	
	
	private Connection conn=null;
	private PreparedStatement pre;
	private ResultSet resultSet;

	private boolean status;
	private ResourceBundle resourceBundle;
	
	public ProductImpl()
	{
		resourceBundle=ResourceBundle.getBundle("com/hsbc/auction/resources/db");
	}
	

	@Override
	public boolean addCategory(Category category) throws DBConnCreationException {
		// TODO Auto-generated method stub
		
		try (Connection conn=DBHelper.getConnection())
		{		
		pre=conn.prepareStatement(resourceBundle.getString("addCategory"));
		
		pre.setInt(1, category.getCategoryUniqueId());
		pre.setString(2, category.getCategoryName());
		pre.setString(3, category.getCategoryDescription());
		
		pre.executeUpdate();
		conn.commit();
		status=true;
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			throw new DBConnCreationException("Connection Error Occurred");
		}
		
		return status;
	}
	
	@Override
	public  int getUserId(String userName) throws SQLException {
		// TODO Auto-generated method stub
		int sellerId =0;
		try {
			conn=DBHelper.getConnection();
			
			System.out.println(conn);
			System.out.println("Connection Created....");
			
			String query = "SELECT USER_ID FROM AUCTION_USER WHERE USER_NAME = ?";
			PreparedStatement pstmt = conn.prepareStatement(query);
		    pstmt.setString(1, userName);			
		    ResultSet rs = pstmt.executeQuery();
		   // System.out.println("rs = "+ rs);
			while(rs.next())
			{
				sellerId=Integer.parseInt(rs.getString("User_Id"));

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

		finally
		{
			conn.close();

		}
		return sellerId;

	}
	
	

	@Override
	public boolean addProduct(Product product) throws DBConnCreationException, SQLException {
		// TODO Auto-generated method stub
		
		
		boolean status = false;
		try {	
			System.out.println("in add product ....");
			try {
				conn=DBHelper.getConnection();
				
				System.out.println(conn);
				System.out.println("Connection Created....");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println(e.getMessage());
			}
			
			//conn=DBHelper.getConnection();
			
			
					
			pre = conn.prepareStatement(resourceBundle.getString("addProduct"));

			pre.setString(1, product.getProductName());
			pre.setString(2, product.getProductCategory());
			pre.setString(3, product.getProductDescription());
			pre.setDouble(4, product.getProductActualPrice());
			pre.setInt(5, product.getProductQuantity());
			pre.setInt(6,product.getProductUserId());

			
			System.out.println("Correct...");
			pre.executeUpdate();
			conn.commit();
			System.out.println("Working ... ");
			status = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error Code"+e.getErrorCode());
			System.out.println(e.getMessage());
			e.printStackTrace();

			
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			throw new DBConnCreationException("Connection Error Occurred");
		}
		finally
		{
			conn.close();

		}
		return status;
		
		/*
		 * try (Connection conn=DBHelper.getConnection()) {
		 * pre=conn.prepareStatement(resourceBundle.getString("addProduct")); try {
		 * pre.setInt(1, product.getProductUniqueId()); pre.setString(2,
		 * product.getProductName()); pre.setString(3, product.getProductCategory());
		 * pre.setString(4, product.getProductDescription()); pre.setDouble(5,
		 * product.getProductActualPrice()); pre.setInt(6,
		 * product.getProductQuantity()); }catch(Exception e){
		 * System.out.println(e.getMessage()); e.printStackTrace(); }
		 * 
		 * 
		 * //pre.setInt(7, product.getProductUserId()); try { pre.executeUpdate();
		 * conn.commit(); }catch(Exception e){ System.out.println(e.getMessage());
		 * e.printStackTrace(); }
		 * 
		 * status=true;
		 * 
		 * 
		 * } catch (SQLException e) { // TODO Auto-generated catch block
		 * 
		 * throw new DBConnCreationException("Connection Error Occurred"); }
		 * 
		 * return status;
		 */
	}
	
	

	@Override
	public boolean ScheduleAuction(Product auction) throws DBConnCreationException {
		// TODO Auto-generated method stub
		
		try (Connection conn=DBHelper.getConnection())
		{		
		pre=conn.prepareStatement(resourceBundle.getString("scheduleAuction"));
			
		pre.setInt(1, auction.getProductUniqueId());
		pre.setDouble(2, auction.getMinBidValue());
		pre.setDate(3, Date.valueOf(auction.getBidStartDate()));	
		pre.setDate(4, Date.valueOf(auction.getBidEndDate()));
		pre.setInt(5, auction.getAuctionUserId());
		pre.setDouble(6, auction.getSoldPrice());
		pre.setString(7, (auction.getStatus()).toString());
		
		pre.executeUpdate();
		conn.commit();
		status=true;
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			throw new DBConnCreationException("Connection Error Occurred");
		}
		
		return status;
	}


	@Override
	public ArrayList<Product> getproducts(int userId) {
		// TODO Auto-generated method stub
		ArrayList<Product> productlist = new ArrayList<Product>();
		Product prod =null;
		try {
			conn = DBHelper.getConnection();
			System.out.println("conn established");
			pre = conn.prepareStatement(resourceBundle.getString("getAllProducts"));
			pre.setInt(1, userId);			
			System.out.println("query updated");
			resultSet = pre.executeQuery();
			while (resultSet.next()) {
				prod = new Product();
				prod.setProductName(resultSet.getString("Product_Name"));
//				prod.setProductDescription(resultSet.getString("Product_Category"));
//				prod.setProductDescription(resultSet.getString("Product_Description"));
				prod.setProductActualPrice(resultSet.getDouble("Actual_Price"));
				System.out.println("product ="+prod);
				productlist.add(prod);
			}
			System.out.println("productlist updated");
			for(Product prodct1:productlist) {
				System.out.println(prodct1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		return  productlist;
	}


	

}
