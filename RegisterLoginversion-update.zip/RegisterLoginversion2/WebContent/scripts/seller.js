/**
 * 
 */
function countryAjaxFunction(){
    let ajaxRequest;
    try{
        ajaxRequest = new XMLHttpRequest();
    } catch (e){
        try{
            ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP3.0"); }
        catch (e){alert("Your browser broke!");
            return false;
        }
    }

    ajaxRequest.onreadystatechange = function(){
        if(ajaxRequest.readyState == 4 && ajaxRequest.status == 200){
            let response=JSON.parse(ajaxRequest.responseText);
            let dataList=document.querySelector("#countryList");
            response.forEach(obj=>{
               console.log(obj.name);
               option=document.createElement("option");
               text=document.createTextNode(obj.name);
               option.appendChild(text);
               dataList.appendChild(option);
              })
        }
    }

    ajaxRequest.open("GET",
        "http://localhost:8080/RegisterLoginversion2/LoginController",
        true);
    ajaxRequest.send(null);
}
