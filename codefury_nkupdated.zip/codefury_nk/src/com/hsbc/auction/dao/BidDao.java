package com.hsbc.auction.dao;

import java.util.ArrayList;


import com.hsbc.auction.models.BidPlace;
import com.hsbc.auction.models.Product;

public interface BidDao {
	ArrayList<Product> scheduledProd(int userId);
	boolean storeBidValue (BidPlace placeBid);
}
