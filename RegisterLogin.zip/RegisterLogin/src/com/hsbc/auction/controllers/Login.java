package com.hsbc.auction.controllers;

import java.io.IOException;
//import java.io.PrintWriter;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hsbc.auction.dao.CustomerDao;
import com.hsbc.auction.dao.CustomerImpl;
import com.hsbc.auction.models.Customer;



/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Customer customer=new Customer();
		CustomerDao customerDao=new CustomerImpl();
		PrintWriter out=response.getWriter();
	    response.setContentType("text/html");
	    String email = request.getParameter("email");
	    customer.setEmail(email);
	    
	    String borsType= customerDao.validateLogin(customer);
	    System.out.println(borsType);
	    if( !borsType.equals("false")) {
	    	HttpSession session = request.getSession();
	    	session.setAttribute("email", email);
	    	if(borsType.equals("Buyer")) {
	    		request.getRequestDispatcher("BuyerPage.jsp").forward(request, response);
	    	}
	    	else {
	    		request.getRequestDispatcher("Seller.jsp").forward(request, response);
	    	}
	    	
	    }
	    else {
	    	out.println("<p style='float:right;color:red'>Login Credentials are not valid.</p>");
        	request.getRequestDispatcher("Login.jsp").include(request, response);
	    }
	    
	    
	    
	}

}
