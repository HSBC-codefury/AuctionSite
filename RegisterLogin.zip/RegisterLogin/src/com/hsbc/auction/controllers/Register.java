package com.hsbc.auction.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hsbc.auction.dao.CustomerDao;
import com.hsbc.auction.dao.CustomerImpl;
import com.hsbc.auction.models.Customer;

/**
 * Servlet implementation class Register
 */


//THIS PAGE IS TO RETRIEVE THE INFORMATION Send bY THE JSP PAGE
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email = request.getParameter("email");
		String pwd = request.getParameter("psw");	
		String bors = request.getParameter("bors");
		Customer customer = new Customer();
		CustomerDao custDao = new CustomerImpl();
		PrintWriter out = response.getWriter();
		customer.setEmail(email);	
		customer.setPassword(pwd);
		customer.setBors(bors);
		boolean result = custDao.addCustomer(customer);
		if(result) {
			System.out.println("Record added successfully");
			out.println(customer.getEmail());
			out.println(customer.getBors());
			
		}
		
	}

}
