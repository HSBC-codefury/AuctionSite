package com.hsbc.auction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.hsbc.auction.helper.DBHelper;
import com.hsbc.auction.models.Customer;




public class CustomerImpl implements CustomerDao{
	private Connection conn = null;
	private ResourceBundle resourceBundle;
	private PreparedStatement prep;
	private ResultSet resultSet;
	private String borsType;
	
	public CustomerImpl() {
		resourceBundle = ResourceBundle.getBundle("com/hsbc/auction/resources/db");
	}
	
	@Override
	public boolean addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		boolean status= false;
		try {
			Connection conn  = DBHelper.getConnection();
			System.out.print(conn);
			System.out.println("coonnected");
			
			prep = conn.prepareStatement(resourceBundle.getString("addCustomer"));
			System.out.println(prep);
			prep.setString(1, customer.getEmail());
			prep.setString(2, customer.getPassword());
			prep.setString(3, customer.getBors());
			prep.executeUpdate();
			System.out.println("data entered");
			conn.commit();
			status = true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
//			try {
////				conn.close();
//			} catch (SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
		}
		return status;
	}

	@Override
	public String validateLogin(Customer customer) {
	// TODO Auto-generated method stub
		
		try {
			conn=DBHelper.getConnection();
			prep=conn.prepareStatement(resourceBundle.getString("loginQuery"));
			prep.setString(1, customer.getEmail());			
			resultSet=prep.executeQuery();
		
			if(resultSet.next())
			{	
				borsType = resultSet.getString("BORS");
				
			}
			else {
				borsType="false";
			}
		  
		    
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getStackTrace());
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return borsType;

	}

	

	
}
