package com.hsbc.auction.dao;

import com.hsbc.auction.models.Customer;

public interface CustomerDao {
	
	boolean addCustomer(Customer customer);
	String validateLogin(Customer customer);
	
	
}
