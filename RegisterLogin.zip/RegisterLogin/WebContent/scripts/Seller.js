 var addProd = document.querySelector("#addproduct")
 
 addProd.addEventListener("click",()=>{ 
	window.location.href = "AddProduct.jsp" 
 })
 
 var scheduleAuction = document.querySelector("#scheduleauction")

 scheduleAuction.addEventListener("click",()=>{ 
	window.location.href = "ScheduleAuction.jsp" 
 })