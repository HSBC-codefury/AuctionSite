package com.hsbc.auction.exceptions;

public class ColumnInvalidException  extends Exception{
	
	public ColumnInvalidException(String message) {
		super(message);
	}
}
