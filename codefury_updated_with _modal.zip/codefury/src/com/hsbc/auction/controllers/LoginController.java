package com.hsbc.auction.controllers;

import java.io.IOException;
//import java.io.PrintWriter;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hsbc.auction.dao.ProductDao;
import com.hsbc.auction.dao.ProductImpl;
import com.hsbc.auction.dao.UserDao;
import com.hsbc.auction.dao.UserImpl;
import com.hsbc.auction.models.Product;
import com.hsbc.auction.models.User;

/**
 * Servlet implementation class Login
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		User user = new User();
		UserDao userDao = new UserImpl();
		Product product = new Product();
		ArrayList<Product> displayprod = new ArrayList<Product>();
		ProductDao productDao = new ProductImpl();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String username = request.getParameter("username");
		user.setUserName(username);
		List<User> userList = new ArrayList<User>();
		userList = userDao.validateLogin(user);
//	    System.out.println(userList);
		if (!userList.isEmpty()) {
			HttpSession session = request.getSession();
			session.setAttribute("username", username);

			try {
				displayprod = (ArrayList<Product>) productDao.getproducts(productDao.getUserId(username));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.setAttribute("productList",displayprod);
			request.setAttribute("pageName", "login");
			for (User userdetails : userList) {
				session.setAttribute("phoneNo", userdetails.getContactNo());
				session.setAttribute("email", userdetails.getEmail());
				if (userdetails.getUserType().equals("Buyer")) {
					request.getRequestDispatcher("BuyerPage.jsp").forward(request, response);
				} else {

					request.getRequestDispatcher("Seller.jsp").forward(request, response);
				}

			}

		} else {
			out.println("<p style='float:right;color:red'>Login Credentials are not valid.</p>");
			request.getRequestDispatcher("Login.jsp").include(request, response);
		}

	}

}
