package com.hsbc.auction.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.hsbc.auction.exceptions.ColumnInvalidException;
import com.hsbc.auction.exceptions.DBConnCreationException;
import com.hsbc.auction.models.Category;
import com.hsbc.auction.models.Product;

public interface ProductDao {
	
	boolean addCategory(Category category) throws DBConnCreationException;
	boolean addProduct(Product product) throws DBConnCreationException, SQLException;
	int getUserId(String userName) throws SQLException;
	boolean ScheduleAuction(Product auction) throws DBConnCreationException;
	ArrayList<Product> getproducts(int userId);


}
