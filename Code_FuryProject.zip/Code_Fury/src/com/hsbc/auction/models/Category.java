package com.hsbc.auction.models;

public class Category {
	private int uniqueCategoryId;
	private String categoryName;
	private String categoryDescription;
	public int getUniqueCategoryId() {
		return uniqueCategoryId;
	}
	public void setUniqueCategoryId(int uniqueCategoryId) {
		this.uniqueCategoryId = uniqueCategoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getCategoryDescription() {
		return categoryDescription;
	}
	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}
	
}
