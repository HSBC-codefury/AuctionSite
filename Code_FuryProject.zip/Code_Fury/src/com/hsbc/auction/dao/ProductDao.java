package com.hsbc.auction.dao;

import com.hsbc.auction.models.Category;
import com.hsbc.auction.models.Product;

public interface ProductDao {
	boolean addCategory(Category category) ;
	boolean addProduct(Product product) ;
	boolean addScheduleAuction(int uniqueProductId) ;
	boolean validateScheduleAuction(Product product);

}
