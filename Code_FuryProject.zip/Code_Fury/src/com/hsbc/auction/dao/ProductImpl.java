package com.hsbc.auction.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.hsbc.auction.helper.DBHelper;
import com.hsbc.auction.models.Category;
import com.hsbc.auction.models.Product;

public class ProductImpl implements ProductDao
{
	private Connection conn = null;
	private ResourceBundle resourceBundle;
	private PreparedStatement pre;
	private ResultSet resultSet;
	private Product products;
	private static int categoryId = 100;
	private static int productId=200;
	private static int uniqueId=1000;

	@Override
	public boolean addCategory(Category category) {
		// TODO Auto-generated method stub
		boolean status = false;
		try {
			conn = DBHelper.getConnection();
			pre = conn.prepareStatement(resourceBundle.getString("addCategory"));
			categoryId++;
			pre.setInt(1, categoryId);
			System.out.println("check1");
			pre.setString(2,category.getCategoryName());
			System.out.println("check2");
			pre.setString(3, category.getCategoryDescription());
			System.out.println("check3");		
			pre.executeUpdate();
			System.out.println("check11");
			conn.commit();
			status = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("didntget stored \n" + "\n" + "import com.hsbc.auction.helper.DBHelper;\n"
					+ "import com.hsbc.auction.models.User;in db");
			System.out.println(e.getMessage());
			e.printStackTrace();
//			throw new SQLException("Connection Error Occurred");
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return status;		
	}

	@Override
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
		boolean status = false;
		try {
			conn = DBHelper.getConnection();
			pre = conn.prepareStatement(resourceBundle.getString("addProduct"));
			productId++;
			pre.setInt(1,productId);
			pre.setString(2,product.getProductName());
			pre.setString(3,product.getCategory().getCategoryName().toString());
			pre.setString(4, product.getDescription());	
			pre.setDouble(5,product.getActualPrice());
			pre.setInt(6,product.getQuantity());
			pre.setInt(7,product.getSellerId());
			pre.executeUpdate();
			System.out.println("check1!!!");
			conn.commit();
			status = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("didntget stored \n" + "\n" + "import com.hsbc.auction.helper.DBHelper;\n"
					+ "import com.hsbc.auction.models.User;in db");
			System.out.println(e.getMessage());
			e.printStackTrace();
//			throw new SQLException("Connection Error Occurred");
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return status;	
	}

	@Override
	public boolean addScheduleAuction(int uniqueProductId) {
		// TODO Auto-generated method stub
		boolean status = false;
		try {
			conn = DBHelper.getConnection();
			pre = conn.prepareStatement(resourceBundle.getString("addScheduleAuction"));
			uniqueId++;
			pre.setInt(1,uniqueId);
			pre.setInt(2,uniqueProductId);
			pre.setInt(3,products.getMinBidValue());
			pre.setDate(4, Date.valueOf(products.getBidStartDate()));
			pre.setDate(5, Date.valueOf(products.getBidEndDate()));
			pre.setInt(6, products.getBuyerId());
			pre.setDouble(7,products.getSoldPrice());
			pre.setString(8,products.getStatus().toString());
			pre.executeUpdate();
			System.out.println("check1!!!");
			conn.commit();
			status = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("didntget stored \n" + "\n" + "import com.hsbc.auction.helper.DBHelper;\n"
					+ "import com.hsbc.auction.models.User;in db");
			System.out.println(e.getMessage());
			e.printStackTrace();
//			throw new SQLException("Connection Error Occurred");
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return status;	
	}

	@Override
	public boolean validateScheduleAuction(Product product) {
		return false;
		// TODO Auto-generated method stub
		
	}

}
